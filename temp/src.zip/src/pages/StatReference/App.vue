<template>
  <div class="base-container">
    <div class="pane1">
      <p class="left-top"><a href="./">げんかるく</a></p>
      <p>&nbsp;</p>
      <h2>参照ステータス一覧</h2>
      <p>&nbsp;</p>
    </div>
    []
    <div class="pane2">
      <vue-good-table :columns="columns" :rows="[]" />
    </div>

    <div class="footer">
    </div>
  </div>
</template>
<script lang="ts">
import _ from 'lodash';
import 'vue-good-table-next/dist/vue-good-table-next.css'
import { computed, defineComponent, reactive, ref } from "vue";
import {
  ARTIFACT_SET_MASTER,
  CHARACTER_MASTER,
  OPTION1_MASTER,
  OPTION2_MASTER,
  TCharacterDetail,
  TEAM_OPTION_MASTER,
  TWeaponDetail,
  WEAPON_MASTER,
} from "@/master";
import CompositionFunction from "@/components/CompositionFunction.vue";

export default defineComponent({
  name: "TeamOptionList",
  components: {
    'vue-good-table': require('vue-good-table-next').VueGoodTable,
  },
  setup() {
    const { displayName, displayStatName } = CompositionFunction();

    const columns = [
      { label: 'ソース', field: 'source', },
      { label: '名称', field: 'nameWithCategory', html: true, },
      { label: '説明', field: 'description', html: true, width: '50%', },
      { label: '関連ステータス', field: 'stats', html: true, },
    ];

    const initialized = ref(false);

    const TGT_RE = /.*?([^0-9.+\-*/%]+)V[1-3]/;
    const REF_RE = /.*?([^0-9.+\-*/%]+)X[1-7].*/;

    function parseDetail(detail: any, label: string) {
      let result;
      let tgtStat;
      let refStat;
      if (_.isString(detail?.種類)) {
        let reRet = TGT_RE.exec(detail.種類);
        if (reRet) {
          tgtStat = reRet[1];
        }
      }
      if (_.isString(detail?.数値)) {
        let reRet = REF_RE.exec(detail.数値);
        if (reRet) {
          refStat = reRet[1];
        } else if (detail.数値.indexOf('#') != -1) {
          refStat = detail.数値;
        }
      } else if (_.isPlainObject(detail?.数値)) {
        for (const key of Object.keys(detail.数値)) {
          let reRet = REF_RE.exec(detail.数値[key]);
          if (reRet) {
            refStat = reRet[1];
          }
        }
      }
      if (tgtStat || refStat) {
        result = {
          label3: label,
          name: detail?.名前,
          tgtStat: tgtStat,
          refStat: refStat,
        };
      }
      return result;
    }

    function parseCharacterDetail(characterDetail: any) {
      let result = [];
      const nameFormulaMap: Map<string, string> = new Map();
      for (const category of ['元素スキル', '元素爆発']) {
        const talentObj = characterDetail[category];
        if (!('詳細' in talentObj)) continue;
        for (const detailEntry of talentObj.詳細) {
          const subRet = parseDetail(detailEntry, category);
          if (subRet) {
            subRet.name = talentObj.名前;
            result.push(subRet);
            if (subRet.refStat) {
              nameFormulaMap.set(category + '#' + subRet.name, subRet.refStat);
            }
          }
        }
      }
      for (const talentObj of characterDetail.固有天賦) {
        if (!('詳細' in talentObj)) continue;
        for (const detailEntry of talentObj.詳細) {
          const subRet = parseDetail(detailEntry, '固有天賦');
          if (subRet) {
            subRet.name = talentObj.名前;
            result.push(subRet);
          }
        }
      }
      if ('命ノ星座' in characterDetail) {
        for (const constellation of Object.keys(characterDetail.命ノ星座)) {
          const talentObj = characterDetail.命ノ星座[constellation];
          if (!('詳細' in talentObj)) continue;
          for (const detailEntry of talentObj.詳細) {
            const subRet = parseDetail(detailEntry, '命ノ星座 第' + constellation + '重');
            if (subRet) {
              subRet.name = talentObj.名前;
              result.push(subRet);
            }
          }
        }
      }
      if ('チームバフ' in characterDetail) {
        for (const detailEntry of characterDetail.チームバフ) {
          const subRet = parseDetail(detailEntry, '-');
          if (subRet) {
            subRet.name = detailEntry?.名前 ?? detailEntry?.条件;
            result.push(subRet);
          }
        }
      }
      const work = [];
      for (const entry of _.uniqWith(result, _.isEqual)) {
        if (entry.refStat && entry.refStat.indexOf('#') != -1) {
          const formula = nameFormulaMap.get(entry.refStat);
          if (formula) {
            entry.refStat = formula;
          } else {
            continue;
          }
        }
        work.push(entry);
      }
      return work;
    }

    function parseWeaponDetail(weaponDetail: any) {
      let result = [];
      const nameFormulaMap: Map<string, string> = new Map();
      if ('武器スキル' in weaponDetail) {
        const talentObj = weaponDetail['武器スキル'];
        if ('詳細' in talentObj) {
          for (const detailEntry of talentObj.詳細) {
            const subRet = parseDetail(detailEntry, '-');
            if (subRet) {
              if (subRet.refStat && detailEntry.名前) {
                nameFormulaMap.set('その他#' + detailEntry.名前, subRet.refStat);
              } else {
                subRet.name = talentObj.名前;
                result.push(subRet);
              }
            }
          }
        }
      }
      if ('チームバフ' in weaponDetail) {
        for (const detailEntry of weaponDetail.チームバフ) {
          console.log(detailEntry);
          const subRet = parseDetail(detailEntry, '-');
          if (subRet) {
            subRet.name = detailEntry?.名前 ?? detailEntry?.条件;
            result.push(subRet);
          }
        }
      }
      if (nameFormulaMap.size) {
        console.log(nameFormulaMap);
      }
      const work = [];
      for (const entry of _.uniqWith(result, _.isEqual)) {
        if (entry.refStat && entry.refStat.indexOf('#') != -1) {
          const formula = nameFormulaMap.get(entry.refStat);
          if (formula) {
            entry.refStat = formula;
          } else {
            continue;
          }
        }
        work.push(entry);
      }
      return work;
    }

    async function initialize() {
      const characterMasterMap: Map<string, TCharacterDetail> = new Map();
      const weaponMasterMap: Map<string, TWeaponDetail> = new Map();
      const promiseValues1 = Object.keys(CHARACTER_MASTER).map(key => fetch((CHARACTER_MASTER as any)[key].import)
        .then(resp => resp.json())
        .then(json => {
          characterMasterMap.set(key, json);
        }));
      const promiseValues2: Promise<void>[] = [];
      Object.keys(WEAPON_MASTER).forEach(weaponType => {
        promiseValues2.push(
          ...Object.keys((WEAPON_MASTER as any)[weaponType]).map(key => fetch((WEAPON_MASTER as any)[weaponType][key].import)
            .then(resp => resp.json())
            .then(json => {
              weaponMasterMap.set(key, json);
            })));
      });
      Promise.all([...promiseValues1, ...promiseValues2]).then(() => {
        const list: any[] = [];
        characterMasterMap.forEach((value, key) => {
          list.push(...parseCharacterDetail(value).map(s => _.merge({ label1: 'キャラクター', label2: key }, s)));
        });
        weaponMasterMap.forEach((value, key) => {
          list.push(...parseWeaponDetail(value).map(s => _.merge({ label1: '武器', label2: key }, s)));
        });
        console.log(list);
        initialized.value = true;
      });
    }
    initialize();

    return {
      displayName,

      columns,
    };
  },
});
</script>
<style>
#app {
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
}

.base-container {
  display: grid;
  grid-template-columns: 1fr;
  grid-template-rows: autoauto auto;
  grid-template-areas:
    "pane1"
    "pane2"
    "footer";
}
</style>
<style scoped>
.pane1 {
  position: relative;
}

.left-top {
  position: absolute;
  left: 5px;
  top: 0;
}

.pane2 {
  text-align: left;
}

h3 {
  padding-left: 10px;
}
</style>
