// @ts-check

/**
 * セレクターに使用できない文字をエスケープします
 * 
 * @param {string} val 
 * @returns {string}
 */
function selectorEscape(val) {
    return val.replace(/[ !"#$%&'()*+,.\/:;<=>?@\[\\\]^`{|}~]/g, '\\$&');
}

/**
 * 加算関数です
 * 
 * @param {number} value1 
 * @param {number} value2 
 * @param {number} opt_max 
 * @returns {number}
 */
const addDecimal = function (value1, value2, opt_max = null) {
    let result = Math.floor((value1 * 100 + value2 * 100) / 10) / 10;
    if (opt_max != null) {
        result = Math.min(result, opt_max);
    }
    return result;
}

/**
 * 代入先のstep属性に併せて丸めた数値をセットします
 * 
 * @param {string} selector 
 * @param {number} value 
 */
function setInputValue(selector, value) {
    let step = $(selector).prop('step');
    let newValue = value;
    if (step && Number(step) < 1) {
        newValue = Number(value.toFixed(1));
    } else {
        newValue = Math.round(value);
    }
    $(selector).val(newValue);
}

/**
 * Mapのvalue(Array)にvalueを追加(push)します
 * 
 * @param {Map} map 
 * @param {string} key 
 * @param {string} value 
 */
function pushToMapValueArray(map, key, value) {
    if (value == null) {
        if (!map.has(key)) {
            map.set(key, null);
        }
    } else if (map.has(key)) {
        let oldValue = map.get(key);
        if (oldValue == null) {
            map.set(key, [value]);
        } else if (!oldValue.includes(value)) {
            map.get(key).push(value);
        }
    } else {
        map.set(key, [value]);
    }
}

/**
 * オブジェクトのプロパティ値を同名の要素にセットします
 * 
 * @param {Object} obj 
 * @param {string} prefix 
 * @param {string} postfix 
 */
function setObjectPropertiesToElements(obj, prefix, postfix) {
    Object.keys(obj).forEach(propName => {
        let inputElem = document.getElementById(prefix + propName + postfix);
        if (inputElem) {
            let value = obj[propName];
            let step = $(inputElem).prop('step');
            if (step && Number(step) < 1) {
                value = value.toFixed(1);
            } else {
                value = Math.round(value);
            }
            $(inputElem).val(value);
        }
    });
}

/**
 * 
 * @param {Object} obj 
 */
function setObjectPropertiesToTableTd(obj) {
    Object.keys(obj).forEach(propName => {
        let valueElem = document.getElementById(propName + 'Value');
        if (valueElem) {
            let value = obj[propName];
            let inputElem = document.getElementById(propName + 'Input');
            if (inputElem) {
                if ($(inputElem).prop('step') && Number($(inputElem).prop('step')) < 1) {
                    value = Math.round(value * 10) / 10;
                } else {
                    value = Math.round(value);
                }
            }
            valueElem.textContent = value;
        }
    });
}

/**
 * 計算式を計算します
 * 
 * @param {Object} statusObj 
 * @param {number | string | string []} formulaArr 
 * @param {number | string | string []} opt_max 
 * @returns 
 */
const calculateFormulaArray = function (statusObj, formulaArr, opt_max = null) {
    let result = 0;
    if (!Array.isArray(formulaArr)) {
        if ($.isNumeric(formulaArr)) {
            result = Number(formulaArr);
        } else {
            if (formulaArr in statusObj) {
                result = statusObj[formulaArr];
            } else {
                console.error(statusObj, formulaArr, opt_max);
            }
        }
    } else {
        let operator = null;
        formulaArr.forEach(entry => {
            let subResult = 0;
            if (['+', '-', '*', '/'].includes(entry)) {
                operator = entry;
                return;
            } else if ($.isNumeric(entry)) {
                subResult = Number(entry);
            } else if (Array.isArray(entry)) {
                subResult = calculateFormulaArray(statusObj, entry);
            } else {
                if (entry in statusObj) {
                    subResult = Number(statusObj[entry]);
                } else if (entry.indexOf('#') != -1) {
                    let nameArr = entry.split('#');
                    if ('ダメージ計算' in statusObj && nameArr[0] in statusObj['ダメージ計算']) {
                        let damageArrArr = statusObj['ダメージ計算'][nameArr[0]];
                        let damage = null;
                        for (let damageArr of damageArrArr) {
                            if (nameArr[1] == damageArr[0]) {
                                damage = damageArr[4];  // 非会心
                                break;
                            }
                        }
                        if (damage != null) {
                            subResult = damage;
                        } else {
                            console.error(statusObj, formulaArr, opt_max, entry);
                        }
                    }
                } else {
                    console.error(statusObj, formulaArr, opt_max);
                }
            }
            if (operator == null) {
                result += subResult;
            } else {
                switch (operator) {
                    case '+':
                        result += subResult;
                        break;
                    case '-':
                        result -= subResult;
                        break;
                    case '*':
                        result *= subResult;
                        result = Math.floor(result * 100) / 100;
                        break;
                    case '/':
                        result /= subResult;
                        break;
                }
            }
        });
    }
    if (opt_max != null) {
        let maxValue = calculateFormulaArray(statusObj, opt_max);
        if (result > maxValue) {
            result = maxValue;
        }
    }
    //    result = Math.floor(result * 100) / 100;
    return result;
}

// 文字列を解析して、計算式Arrayを作成します
// 数値|数値%|数値%文字列|文字列
function analyzeFormulaStrSub(str, defaultItem = null) {
    let resultArr = [];
    if ($.isNumeric(str)) {
        resultArr.push(Number(str));
    } else {
        let strArr = str.split('%');
        if (strArr.length == 1) {
            resultArr.push(strArr[0]);
        } else {
            resultArr.push(Number(strArr[0]) / 100);
            resultArr.push('*');
            if (strArr[1].length > 0) {
                resultArr.push(strArr[1]);
            } else if (defaultItem != null) {
                resultArr.push(defaultItem);
            }
        }
    }
    return resultArr;
}

const analyzeFormulaStr = function (str, defaultItem = null) {
    let resultArr = [];
    let re = new RegExp('([\\+\\-\\*/]?)([^\\+\\-\\*/]+)(.*)');
    let workStr = str;
    while (true) {
        let reRet = re.exec(workStr);
        if (!reRet) {
            resultArr.push(workStr);
            break;
        }
        if (reRet[1]) { // + - * /
            resultArr.push(reRet[1]);
        }
        resultArr.push(analyzeFormulaStrSub(reRet[2], defaultItem));
        if (!reRet[3]) {
            break;
        }
        workStr = reRet[3];
    }
    return resultArr;
}

// const analyzeFormulaStr_ = function (str, defaultItem = null) {
//     let resultArr = [];
//     let re = new RegExp('([0-9\\.]+%[^0-9\\.%\\+\\-\\*/]+|[0-9\\.]+%|\\-?[0-9\\.]+|[^0-9\\.%\\+\\-\\*/]+)([\\+\\-\\*/]?)(.*)');
//     let workStr = str;
//     while (true) {
//         let reRet = re.exec(workStr);
//         if (!reRet) {
//             resultArr.push(workStr);
//             break;
//         }
//         resultArr.push(analyzeFormulaStrSub(reRet[1], defaultItem));
//         if (reRet[2]) {
//             resultArr.push(reRet[2]);
//             if (reRet[3]) {
//                 workStr = reRet[3];
//                 continue;
//             } else {
//                 console.error(str, defaultItem);
//             }
//         } else if (reRet[3]) {
//             console.error(str, defaultItem);
//         }
//         break;
//     }
//     return resultArr;
// }

// 防御補正を計算します
//function calcurate防御補正(level, enemyLevel, opt_def = 0, opt_ignoreDef = 0) {
//    let calcIgnoreDef = opt_ignoreDef / 100;
//    let calcDef = opt_def / 100;
//    let result = (level + 100) / ((1 - calcIgnoreDef) * (1 + calcDef) * (enemyLevel + 100) + level + 100);
//    return result;
//}

// 耐性補正を計算します
//function calculate耐性補正(res) {
//    if (res < 0) {
//        res = 100 - res / 2;
//    } else if (res < 75) {
//        res = 100 - res;
//    } else {
//        res = 100 / (4 * res + 100)
//    }
//    return res / 100;
//}

// Twitter
// text ツイートの本文
// url URLのシェア
// hashtags ハッシュタグ
// via アカウント関連付け @viaさんから
function openTwitter(text, url, opt_hashtags = null, opt_via = null) {
    const baseUrl = 'https://twitter.com/intent/tweet?';
    const params = [];
    params.push(['text', text]);
    params.push(['url', url]);
    if (opt_hashtags) {
        params.push(['hashtags'], opt_hashtags);
    }
    if (opt_via) {
        params.push(['via'], opt_via);
    }
    const query = new URLSearchParams(params).toString();
    const shareUrl = `${baseUrl}${query}`;
    console.log(params);
    console.log(shareUrl);
    window.open(shareUrl);
}

////
const appendOptionElement = function (key, valueObj, selector) {
    if ('disabled' in valueObj && valueObj['disabled']) return;   // とりあえず無効レコードは追加しません
    let myText = key;
    if ('レアリティ' in valueObj) {
        myText = '★' + valueObj['レアリティ'] + ' ' + key;
    }
    $('<option>', {
        text: myText,
        value: key,
        disabled: ('disabled' in valueObj) && valueObj['disabled'],
        selected: ('selected' in valueObj) && valueObj['selected']
    }).appendTo(selector);
};

const appendOptionElements = function (data, selector) {
    $(selector).empty();
    Object.keys(data).forEach(key => {
        if (Array.isArray(selector)) {
            selector.forEach(entry => {
                appendOptionElement(key, data[key], entry);
            });
        } else {
            appendOptionElement(key, data[key], selector);
        }
    });
};

